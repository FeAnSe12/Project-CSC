import { PrismaClient } from "@prisma/client";
import AddProduct from "./addProduct";
import Link from "next/link";
const prisma = new PrismaClient();

const getProducts = async () => {
  const res = await prisma.product.findMany({
    select: {
      id: true,
      title: true,
      price: true,
      brandId: true,
      brand: true,
    },
  });
  return res;
};

const getBrands = async () => {
  const res = await prisma.brand.findMany();
  return res;
};

const Product = async () => {
  const [products, brands] = await Promise.all([getProducts(), getBrands()]);

  return (
    <div>
      <div className="mb-3 flex justify-between items-center">
        <AddProduct brands={brands} />
        <Link
          className="border border-slate-900 text-black px-2 py-2 rounded hover:bg-slate-400 focus-within:file:bg-slate-700 outline-none"
          href="/"
        >
          Back To Home Page
        </Link>
      </div>
      <table className="w-full table table-auto">
        <thead>
          <tr className="bg-gray-200 text-black uppercase">
            <th>#</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Brand</th>
            <th className="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product, index) => (
            <tr key={product.id}>
              <td>{index + 1}</td>
              <td>{product.title}</td>
              <td>{product.price}</td>
              <td>{product.brand.name}</td>
              <td></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Product;
