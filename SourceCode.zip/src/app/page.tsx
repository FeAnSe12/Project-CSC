import Image from "next/image";
import Link from "next/link";
import React from "react";

export default function Home() {
  return (
    <>
      <header className="flex justify-between items-center mb-4">
        <h1 className="text-2xl">Welcome CSC Member</h1>
        <Link
          className="border border-slate-900 text-black px-2 py-1 rounded hover:bg-slate-400 focus-within:file:bg-slate-700 outline-none"
          href="/products"
        >
          Product
        </Link>
      </header>
      <ul></ul>
    </>
  );
}
